// Chris Jacobs
// 8/1/2021
// Hello world
// Displays the message "Hello World"

#include <iostream>
using namespace std;

int main()
{
    cout << "Hello World!\n";

    system("pause");
    return 0;
}

